window.onload = function() {
  document.getElementsByClassName("authorization-link")[0].style.visibility = "hidden";
}
