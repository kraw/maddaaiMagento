define([
  "jquery",
],
function($) {
  "use strict";

  // Here your custom code...
  console.log('Hola');

  return;
});
