<?php

namespace Syrus\Navigation\Plugin;

class Topmenu
{


    public function getCategoryCollection($isActive = true, $level = false, $sortBy = false, $pageSize = false)
    {
	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();	
        $collection = $objectManager->create('\Magento\Catalog\Model\ResourceModel\Category\CollectionFactory')->create();
        $collection->addAttributeToSelect('*');        
        
        // select only active categories
        if ($isActive) {
            $collection->addIsActiveFilter();
        }
                
        // select categories of certain level
        if ($level) {
            $collection->addLevelFilter($level);
        }
        
        // sort categories by some value
        if ($sortBy) {
            $collection->addOrderField($sortBy);
        }
        
        // select certain number of categories
        if ($pageSize) {
            $collection->setPageSize($pageSize); 
        }    
        
        return $collection;
    }

    public function afterGetHtml(\Magento\Theme\Block\Html\Topmenu $topmenu, $html)
    {
	$categories = $this->getCategoryCollection(true, false, 'name', false);
	//$html .= "<ul>";
        $html .= "<li class=\"level0 nav-4 level-top parent ui-menu-item\">";
        $html .= "<a href=\"" . "/" . "\" class=\"level-top ui-corner-all\" aria-haspopup=\"true\" tabindex=\"-1\" role=\"menuitem\">".
            "<span class=\"ui-menu-icon ui-icon ui-icon-carat-1-e\"></span><span>" . __("Home") . "</span>".
            "</a>";
        $html .= "</li>"; 
		$html .= "<li class=\"level0 nav-4 level-top parent ui-menu-item\">";
	$html .= "<a    class=\"level-top ui-corner-all\" aria-haspopup=\"true\" tabindex=\"-1\" role=\"menuitem\">".
             "<span data-toggle=\"collapse\" data-target=\"#test\" >".__("Categorie")."</span>".
            "</a>";
	
	$html .= "<ul style=\"position: absolute; top: 0px; background-color : white !important\" id=\"test\"  class=\"collapse\"  >";
	foreach($categories as $category) {
					if($category->getIncludeInMenu())
            					$html .= "<li style=\"background-color : white; border: 1px grey\"><a href=\"".$category->getUrl()."\" title=\"Show list of tickets\">".$category->getName()."</a></li>";
	}
        $html .= "</ul>";
	$html .= "</li>";
        $html .= "<li class=\"level0 nav-4 level-top parent ui-menu-item\">";
        $html .= "<a href=\"" . "/in-scadenza" . "\" class=\"level-top ui-corner-all\" aria-haspopup=\"true\" tabindex=\"-1\" role=\"menuitem\">".
            "<span class=\"ui-menu-icon ui-icon ui-icon-carat-1-e\"></span><span>" . __("In scadenza") . "</span>".
            "</a>";
        $html .= "</li>";

        $html .= "<li class=\"level0 nav-4 level-top parent ui-menu-item\">";
        $html .= "<a href=\"" . "/conclusi" . "\" class=\"level-top ui-corner-all\" aria-haspopup=\"true\" tabindex=\"-1\" role=\"menuitem\">".
            "<span class=\"ui-menu-icon ui-icon ui-icon-carat-1-e\"></span><span>" . __("Conclusi") . "</span>".
            "</a>";
        $html .= "</li>";

        $html .= "<li class=\"level0 nav-4 level-top parent ui-menu-item\">";
        $html .= "<a href=\"" . "/bidrequest/bidrequest/form" . "\" class=\"level-top ui-corner-all\" aria-haspopup=\"true\" tabindex=\"-1\" role=\"menuitem\">".
                "<span class=\"ui-menu-icon ui-icon ui-icon-carat-1-e\"></span><span>" . __("Crea il tuo bid") . "</span>".
                 "</a>";
        $html .= "</li>";

	$html .= "<li class=\"level0 nav-4 level-top parent ui-menu-item\">";
        $html .= "<a href=\"" . "/valutation-products" . "\" class=\"level-top ui-corner-all\" aria-haspopup=\"true\" tabindex=\"-1\" role=\"menuitem\">".
                "<span class=\"ui-menu-icon ui-icon ui-icon-carat-1-e\"></span><span>" . __("Proposte di Bid") . "</span>".
                 "</a>";
        $html .= "</li>";
	//$html .= "</ul>";

        return $html;
    }
}
