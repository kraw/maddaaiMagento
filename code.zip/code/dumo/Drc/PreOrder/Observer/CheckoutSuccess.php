<?php
namespace Drc\PreOrder\Observer;
use Zend_Debug;

class CheckoutSuccess implements \Magento\Framework\Event\ObserverInterface
{

  public function __construct(
      \Magento\Backend\Block\Template\Context $context
  ){

   $this->_context = $context;
   }


  public function execute(\Magento\Framework\Event\Observer $observer){

    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

    $session = $objectManager->create("\Magento\Customer\Model\Session");
    $customerData = $session->getCustomerData();
    $id_customer = $customerData->getId();

    unset($_COOKIE["$id_customer"]);
    setcookie("$id_customer", '', 0, '/');

    
  }

}

