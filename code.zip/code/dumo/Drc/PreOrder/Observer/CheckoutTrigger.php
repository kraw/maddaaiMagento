<?php
namespace Drc\PreOrder\Observer;
use Zend_Debug;

class CheckoutTrigger implements \Magento\Framework\Event\ObserverInterface
{

  protected $_storeManager;


    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Customer\Model\Session $session,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Framework\Mail\Template\TransportBuilder $_transportBuilder,
        \Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Customer\Model\AccountManagement $acm,
        \Drc\PreOrder\Model\PreorderPendingFactory $pre,
        \Drc\PreOrder\Model\PreorderPending $preModel,
        \Magento\Catalog\Model\ProductFactory $productLoader

    )
    {
        $this->_context = $context;
        $this->_registry = $registry;
        $this->_session = $session;
        $this->cart = $cart;
        $this->_transportBuilder = $_transportBuilder;
        $this->_responseFactory = $responseFactory;
        $this->_acm = $acm;
        $this->_pre = $pre;
        $this->_preModel = $preModel;
        $this->_productLoader = $productLoader;
        $this->_stockItemRepository = $stockItemRepository;


    }


        // ================   START TRIGGER ======================== //
  public function execute(\Magento\Framework\Event\Observer $observer)
  {

    $base_url = $this->_context->getStoreManager()->getStore()->getBaseUrl();
  //  Zend_Debug::dump(get_class_methods($this->_context));


    $customerData = $this->_session->getCustomerData();
    $logged = $this->_session->isLoggedIn();

//    Zend_Debug::dump("is logged = ".$logged);

    if($logged){

      $name = $customerData->getFirstname();
      $products = $this->cart->getItems();
      $email = $customerData->getEmail();
      $id_customer = $customerData->getId();

	
      if(isset($_COOKIE["$id_customer"]) && $_COOKIE["$id_customer"] == "checkout"){
        return $this;
      }


      //GENERO TOKEN
      $token = md5(uniqid($email, true));

      //bid raggiunti
      $bid_raggiunti = array();

      // Step1 - incremento il bid del prodotto
      foreach ($products as $product) {
        $name = $product->getName();  //nome
        $id_product = $product->getProductId(); //id prodotto
        $qty = $product->getQty();  //quantità nel carrello
        $prodotto = $this->_productLoader->create()->load($id_product); //oggetto prodotto

        $product_stock = $this->_stockItemRepository->get($id_product);
        $stock = $product_stock->getQty(); //quantità in stock


        $bid_prodotto = $prodotto->getResource()->getAttribute("bid_target")->getFrontend()->getValue($prodotto); //bid
        $bid_start_date = $prodotto->getResource()->getAttribute("bid_start_date")->getFrontend()->getValue($prodotto);
        $bid_end_date = $prodotto->getResource()->getAttribute("bid_end_date")->getFrontend()->getValue($prodotto);

        //update bid
        $prodotto->setData('bid_target', $bid_prodotto + $qty);
        $prodotto->save();



        //Step2 - aggiungo un record nella tabella dei preorder_pending per ogni prodotto nel carrello
        $this->_preModel->insertPreorderPending($id_customer, $email, $id_product ,$token, $qty);

        $bid_prodotto = $prodotto->getResource()->getAttribute("bid_target")->getFrontend()->getValue($prodotto); //bid updated

        if($bid_prodotto == $stock){
            $bid_raggiunti[] = $id_product;

            //cambiare lo stato del prodotto in stock
            $product_stock->setData('is_in_stock',1);
            $product_stock->save();
        }
      }


      //Step3 - se ha raggiunto la soglia, spedisco l'email a tutti i customer per procedere il checkout
      if(count($bid_raggiunti) > 0){
        foreach ($bid_raggiunti as $id) {

          $preorder_raggiunti = $this->_preModel->getAllCustomerByIdProduct($id);

          foreach ($preorder_raggiunti as $prag) {
              $email = $prag['email'];
              $token = $prag['token'];

              //send email
              $this->send($email,$token,$base_url);
          }
        }
      }


    }

    //REDIRECT ALLA HOME
    $urlBuilder = $this->_context->getUrlBuilder();
    $event = $observer->getEvent();
    $CustomRedirectionUrl = $urlBuilder->getUrl('preorder/confirmcheckout/confirm');
    $this->_responseFactory->create()->setRedirect($CustomRedirectionUrl)->sendResponse();

    exit;

  }



  //============ UTILITY ============== //

    public function getStoreName()
      {
          return $this->_storeManager->getStore()->getName();
      }


     public function send($email,$token,$base_url) {

         //Initialize needed variables
         $your_name = 'Syrus Magento';
         $your_email = 'syrusmagento@gmail.com';
         $your_password = 'danieledaniele';
         $send_to_name = 'My Friend Andrew';
         $send_to_email = $email ;

         //SMTP server configuration
         $smtpHost = 'smtp.gmail.com';
         $smtpConf = array(
          'auth' => 'login',
          'ssl' => 'ssl',
          'port' => '465',
          'username' => $your_email,
          'password' => $your_password
         );
         $transport = new \Zend_Mail_Transport_Smtp($smtpHost, $smtpConf);


        $body = "Per confermare l'ordine
             <a href='".$base_url."preorder/confirmcheckout/confirm?t=$token'>
             clicca qui</a>";

         //Create email
         $mail = new \Zend_Mail();
         $mail->setFrom($your_email, $your_name);
         $mail->addTo($email, $send_to_name);
         $mail->setSubject('Preorder attivo!');
         $mail->setBodyHtml($body);

         //Send
         $sent = true;
         try {
          $mail->send($transport);
         }
         catch (Exception $e) {
          $sent = false;
         }
         Zend_Debug::dump("email mandata con successo");
         //Return boolean indicating success or failure
         return $sent;

        }




}

