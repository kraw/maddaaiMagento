<?php
/**
 * Created by PhpStorm.
 * User: georgeson
 * Date: 01/02/17
 * Time: 16:09
 */

namespace Drc\PreOrder\Model\ResourceModel;


class Bid extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     * Get table name from config
     *
     * @return void
     */
    protected function _construct()
    {
        //$this->_init('foggyline_helpdesk_ticket', 'ticket_id');
    }
}