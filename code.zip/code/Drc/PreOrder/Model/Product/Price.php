<?php
 namespace Drc\PreOrder\Model\Product;
 class Price extends \Magento\Catalog\Model\Product\Type\Price
 {
 
     
 }
