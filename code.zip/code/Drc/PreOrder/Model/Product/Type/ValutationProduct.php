<?php
 
namespace Drc\PreOrder\Model\Product\Type;
 
class ValutationProduct extends \Magento\Catalog\Model\Product\Type\AbstractType {
 
	public function deleteTypeSpecificData(\Magento\Catalog\Model\Product $product) {
	} 
}
