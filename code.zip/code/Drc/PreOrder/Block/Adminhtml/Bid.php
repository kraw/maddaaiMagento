<?php
/**
 * Created by PhpStorm.
 * User: georgeson
 * Date: 01/02/17
 * Time: 15:40
 */

namespace Drc\PreOrder\Block\Adminhtml;

class Bid extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_controller = 'adminhtml';
        $this->_blockGroup = 'Drc_Preorder';
        $this->_headerText = __('Bids');
        parent::_construct();
        $this->removeButton('add');
    }
}